package org.srally2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import org.libsdl.app.SDLActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * SDL hosts the native game (libmain.so). The first argument is the folder with the game images built from the user's
 * srally2.zip (see LauncherActivity). Extra command line options (for example <code>-ires 720</code> or <code>-43</code>)
 * can be put in <code>files/args.txt</code>.
 *
 * On top of the game surface this activity adds (1) the Super3-style touch overlay (Overlay.java) and (2) the preloader
 * image, shown while the game starts. The window extends under a camera cutout so the picture fills the whole screen.
 */
public class MainActivity extends SDLActivity {
    /** How long the preloader image stays on screen before it fades out (milliseconds). */
    private static final int PRELOADER_MS = 4000;

    @Override protected String[] getLibraries() {
        return new String[] { "SDL2", "main" };
    }

    @Override protected String[] getArguments() {
        File base = getExternalFilesDir(null);
        List<String> a = new ArrayList<>();
        a.add(new File(base, "images").getAbsolutePath());
        File extra = new File(base, "args.txt");
        if (extra.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(extra))) {
                String line;
                while ((line = r.readLine()) != null)
                    for (String t : line.trim().split("\\s+")) if (!t.isEmpty() && !t.startsWith("#")) a.add(t);
            } catch (Exception ignored) { }
        }
        return a.toArray(new String[0]);
    }

    /** Called from native code after the settings menu saved new options: relaunch the whole app. */
    public void restartApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> Process.killProcess(Process.myPid()), 300);
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        File base = getExternalFilesDir(null);   // make sure the folder exists so it can be filled over USB / adb
        if (base != null) new File(base, "images").mkdirs();
        if (Build.VERSION.SDK_INT >= 28) {       // draw under the camera cutout: no black bar on the side
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        super.onCreate(savedInstanceState);
        if (mLayout == null) return;             // native libraries failed to load: nothing to decorate
        Overlay overlay = new Overlay(this, new Overlay.Host() {
            @Override public void setNativePaused(boolean paused) {
                SDLActivity.mNextNativeState = paused ? SDLActivity.NativeState.PAUSED : SDLActivity.NativeState.RESUMED;
                SDLActivity.handleNativeState();
            }
            @Override public void pressBack() { MainActivity.this.pressBack(); }
            @Override public void restartGame() { restartApp(); }
            @Override public void exitGame() {
                finishAndRemoveTask();
                new Handler(Looper.getMainLooper()).postDelayed(() -> Process.killProcess(Process.myPid()), 300);
            }
        });
        mLayout.addView(overlay, new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT));
        addPreloader();
    }

    // ---- preloader ----
    private void addPreloader() {
        final ImageView v = new ImageView(this);
        v.setBackgroundColor(Color.WHITE);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setImageResource(R.drawable.preloader);
        v.setClickable(true);                    // swallow touches while it is visible
        mLayout.addView(v, new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT));
        new Handler(Looper.getMainLooper()).postDelayed(() ->
                v.animate().alpha(0f).setDuration(400).withEndAction(() -> {
                    if (mLayout != null) mLayout.removeView(v);
                }).start(), PRELOADER_MS);
    }

    /** The game's settings menu opens on Back (same as the Android back key). Hold the key for a few frames so the game sees it. */
    private void pressBack() {
        onNativeKeyDown(KeyEvent.KEYCODE_BACK);
        new Handler(Looper.getMainLooper()).postDelayed(() -> onNativeKeyUp(KeyEvent.KEYCODE_BACK), 80);
    }
}
