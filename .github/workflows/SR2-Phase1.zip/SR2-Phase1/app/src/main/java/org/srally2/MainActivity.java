package org.srally2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.DisplayCutout;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowInsets;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import org.libsdl.app.SDLActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * SDL hosts the native game (libmain.so). The first argument is the folder with the game images built from the user's
 * srally2.zip (see LauncherActivity). Extra command line options (for example <code>-ires 720</code> or <code>-43</code>)
 * can be put in <code>files/args.txt</code>.
 *
 * On top of the game surface this activity adds (1) the preloader image, shown while the game starts, and (2) a
 * round menu button (top-right, Super3 style) that opens the game's own settings menu.
 */
public class MainActivity extends SDLActivity {
    /** How long the preloader image stays on screen before it fades out (milliseconds). */
    private static final int PRELOADER_MS = 4000;

    @Override protected String[] getLibraries() {
        return new String[] { "SDL2", "main" };
    }

    @Override protected String[] getArguments() {
        File base = getExternalFilesDir(null);
        List<String> a = new ArrayList<>();
        a.add(new File(base, "images").getAbsolutePath());
        File extra = new File(base, "args.txt");
        if (extra.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(extra))) {
                String line;
                while ((line = r.readLine()) != null)
                    for (String t : line.trim().split("\\s+")) if (!t.isEmpty() && !t.startsWith("#")) a.add(t);
            } catch (Exception ignored) { }
        }
        return a.toArray(new String[0]);
    }

    /** Called from native code after the settings menu saved new options: relaunch the whole app. */
    public void restartApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> Process.killProcess(Process.myPid()), 300);
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        File base = getExternalFilesDir(null);   // make sure the folder exists so it can be filled over USB / adb
        if (base != null) new File(base, "images").mkdirs();
        super.onCreate(savedInstanceState);
        if (mLayout == null) return;             // native libraries failed to load: nothing to decorate
        addMenuButton();
        addPreloader();
    }

    // ---- preloader ----
    private void addPreloader() {
        final ImageView v = new ImageView(this);
        v.setBackgroundColor(Color.WHITE);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setImageResource(R.drawable.preloader);
        v.setClickable(true);                    // swallow touches while it is visible
        mLayout.addView(v, new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT));
        new Handler(Looper.getMainLooper()).postDelayed(() ->
                v.animate().alpha(0f).setDuration(400).withEndAction(() -> {
                    if (mLayout != null) mLayout.removeView(v);
                }).start(), PRELOADER_MS);
    }

    // ---- menu button: black 35% disc, white hamburger at ~90% alpha, 44dp, 12dp from the top-right corner ----
    private void addMenuButton() {
        final float d = getResources().getDisplayMetrics().density;
        final int size = Math.round(44 * d), margin = Math.round(12 * d);
        final MenuButton b = new MenuButton(this);
        final RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(size, size);
        lp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        lp.setMargins(0, margin, margin, 0);
        b.setAlpha(0.85f);
        b.setOnClickListener(v -> pressBack());
        mLayout.addView(b, lp);
        if (Build.VERSION.SDK_INT >= 28) {       // keep clear of a camera cutout
            mLayout.postDelayed(() -> {
                WindowInsets wi = getWindow().getDecorView().getRootWindowInsets();
                DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
                if (dc != null) {
                    lp.setMargins(0, margin + dc.getSafeInsetTop(), margin + dc.getSafeInsetRight(), 0);
                    b.setLayoutParams(lp);
                }
            }, 800);
        }
    }

    /** The game's settings menu opens on Back (same as the Android back key). Hold the key for a few frames so the game sees it. */
    private void pressBack() {
        onNativeKeyDown(KeyEvent.KEYCODE_BACK);
        new Handler(Looper.getMainLooper()).postDelayed(() -> onNativeKeyUp(KeyEvent.KEYCODE_BACK), 80);
    }

    private static final class MenuButton extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        MenuButton(Context c) { super(c); }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(89, 0, 0, 0));                       // black, 35%
            cv.drawCircle(w / 2, h / 2, Math.min(w, h) / 2, p);
            p.setColor(Color.argb(230, 255, 255, 255));                // white, ~90%
            float bw = w * 0.44f, bh = h * 0.06f, gap = h * 0.16f, x = (w - bw) / 2, y = h / 2 - bh / 2;
            for (int i = -1; i <= 1; i++)
                cv.drawRoundRect(x, y + i * gap, x + bw, y + i * gap + bh, bh / 2, bh / 2, p);
        }
    }
}
