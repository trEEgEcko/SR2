package org.srally2;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.hardware.input.InputManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import org.libsdl.app.SDLControllerManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Super3-style touch overlay drawn on top of the SDL surface (see UI_SPEC_Super3). It talks to the native game as a
 * virtual gamepad registered through SDL's Java joystick API: steering = left stick X, gas = right trigger,
 * brake = left trigger, view = A, shift up/down = RB / LB, coin = Back, start = Start,
 * test = Start + left stick click, service = Start + right stick click (the bindings the game already uses for pads).
 */
final class Overlay extends FrameLayout {

    interface Host {
        void setNativePaused(boolean paused);
        void pressBack();          // opens the game's own settings menu
        void restartGame();
        void exitGame();
    }

    // ---------------------------------------------------------------- virtual gamepad
    static final class VPad {
        static final int DEV = 9001;
        /** Resting brake value: just above the game's trigger dead zone (~0.5 % brake) so the game always sees pad activity. */
        static final float REST = 0.045f;
        static boolean ready;
        static void init() {
            if (ready) return;
            try {
                // buttons A,B,X,Y,Back,Guide,Start,LS,RS,LB,RB (bits 0..10); 6 axes: lx ly rx ry lt rt; no hats
                SDLControllerManager.nativeAddJoystick(DEV, "Wheel Pad", "virtual-wheel-pad", 0, 0, false, 0x7FF, 6, 0x3F, 0, 0);
                ready = true;
                axis(AX_BRAKE, REST);
            } catch (Throwable ignored) { }
        }
        static void axis(int a, float v) { if (ready) try { SDLControllerManager.onNativeJoy(DEV, a, v); } catch (Throwable ignored) { } }
        static void button(int key, boolean down) {
            if (!ready) return;
            try { if (down) SDLControllerManager.onNativePadDown(DEV, key); else SDLControllerManager.onNativePadUp(DEV, key); }
            catch (Throwable ignored) { }
        }
    }
    private static final int AX_STEER = 0, AX_BRAKE = 4, AX_GAS = 5;

    private static final int ACCENT = 0xFF4DB6F5, CARD = 0xFF25262B, LINE = 0xFF8E9095;
    private static final String[] RATIOS = { "Auto", "4:3", "16:10", "16:9", "21:9" };
    private static final String[] TOUCH = { "Auto", "Always show", "Always hide" };

    private final Host host;
    private final SharedPreferences sp;
    private final float dens;
    private final Handler h = new Handler(Looper.getMainLooper());

    private float opacity;
    private boolean coinStart, testService, userPaused, panelOpen, lastPaused;
    private int touchMode;

    private final List<View> gameplay = new ArrayList<>();
    private View coinBtn, startBtn, pills;
    private IconButton pauseBtn;
    private FrameLayout scrim;
    private LinearLayout card;
    private InputManager.InputDeviceListener padListener;
    private View shield;
    private boolean brakeDown;
    private final Runnable keepAlive = new Runnable() {
        @Override public void run() {
            if (VPad.ready) VPad.axis(AX_BRAKE, brakeDown ? 1f : VPad.REST);
            if (shield != null) shield.setVisibility(VPad.ready ? VISIBLE : GONE);
            h.postDelayed(this, 400);
        }
    };

    Overlay(Context c, Host host) {
        super(c);
        this.host = host;
        dens = c.getResources().getDisplayMetrics().density;
        sp = c.getSharedPreferences("rally_overlay", Context.MODE_PRIVATE);
        opacity = Math.max(0.2f, Math.min(1f, sp.getFloat("opacity", 0.55f)));
        coinStart = sp.getBoolean("coin_start", true);
        touchMode = sp.getInt("touch_mode", 0);
        build(c);
        updateVisibility();
    }

    private int dp(float v) { return Math.round(v * dens); }

    private LayoutParams lp(int wDp, int hDp, int gravity, int l, int t, int r, int b) {
        LayoutParams p = new LayoutParams(dp(wDp), dp(hDp), gravity);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    // ---------------------------------------------------------------- building the controls
    private void build(Context c) {
        // Swallows touches that miss a control, so the game never sees a finger and keeps its own on-screen buttons hidden
        shield = new View(c);
        shield.setClickable(true);
        shield.setVisibility(GONE);
        addView(shield, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Stick stick = new Stick(c);
        addView(stick, lp(160, 160, Gravity.BOTTOM | Gravity.LEFT, 20, 0, 0, 12));
        gameplay.add(stick);

        ImgButton gas = new ImgButton(c, R.drawable.btn_gas, () -> VPad.axis(AX_GAS, 1f), () -> VPad.axis(AX_GAS, 0f));
        addView(gas, lp(96, 96, Gravity.BOTTOM | Gravity.RIGHT, 0, 0, 16, 16));
        gameplay.add(gas);

        ImgButton brake = new ImgButton(c, R.drawable.btn_brake,
                () -> { brakeDown = true; VPad.axis(AX_BRAKE, 1f); },
                () -> { brakeDown = false; VPad.axis(AX_BRAKE, VPad.REST); });
        addView(brake, lp(96, 96, Gravity.BOTTOM | Gravity.RIGHT, 0, 0, 124, 16));
        gameplay.add(brake);

        ImgButton view = new ImgButton(c, R.drawable.btn_view,
                () -> VPad.button(KeyEvent.KEYCODE_BUTTON_A, true), () -> VPad.button(KeyEvent.KEYCODE_BUTTON_A, false));
        addView(view, lp(96, 54, Gravity.RIGHT | Gravity.CENTER_VERTICAL, 0, 0, 16, 0));
        gameplay.add(view);

        ImgButton coin = new ImgButton(c, R.drawable.btn_coin,
                () -> VPad.button(KeyEvent.KEYCODE_BUTTON_SELECT, true), () -> VPad.button(KeyEvent.KEYCODE_BUTTON_SELECT, false));
        addView(coin, lp(96, 48, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0, 0, 14));
        coin.setTranslationX(-dp(52));
        coinBtn = coin;

        ImgButton start = new ImgButton(c, R.drawable.btn_start,
                () -> VPad.button(KeyEvent.KEYCODE_BUTTON_START, true), () -> VPad.button(KeyEvent.KEYCODE_BUTTON_START, false));
        addView(start, lp(96, 48, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0, 0, 14));
        start.setTranslationX(dp(52));
        startBtn = start;

        // TEST / SERVICE pills, top-left
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(pill(c, "TEST", KeyEvent.KEYCODE_BUTTON_THUMBL));
        View gap = new View(c);
        row.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(pill(c, "SERVICE", KeyEvent.KEYCODE_BUTTON_THUMBR));
        addView(row, wrapParams(Gravity.TOP | Gravity.LEFT, 12, 12, 0, 0));
        pills = row;

        // top-right cluster: play/pause, screen ratio, menu (44 dp round, 10 dp apart, 12 dp from the corner)
        IconButton menu = new IconButton(c, 2);
        menu.setOnClickListener(v -> showPanel(0));
        addView(menu, lp(44, 44, Gravity.TOP | Gravity.RIGHT, 0, 12, 12, 0));
        IconButton ratio = new IconButton(c, 1);
        ratio.setOnClickListener(v -> showPanel(2));
        addView(ratio, lp(44, 44, Gravity.TOP | Gravity.RIGHT, 0, 12, 12 + 54, 0));
        pauseBtn = new IconButton(c, 0);
        pauseBtn.setOnClickListener(v -> { userPaused = !userPaused; pauseBtn.invalidate(); applyPause(); });
        addView(pauseBtn, lp(44, 44, Gravity.TOP | Gravity.RIGHT, 0, 12, 12 + 108, 0));
    }

    private LayoutParams wrapParams(int gravity, int l, int t, int r, int b) {
        LayoutParams p = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private TextView pill(Context c, String text, int stickKey) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(18));
        g.setColor(0x59000000);
        g.setStroke(Math.max(1, dp(2)), Color.WHITE);
        t.setBackground(g);
        t.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                VPad.button(KeyEvent.KEYCODE_BUTTON_START, true); VPad.button(stickKey, true);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                VPad.button(stickKey, false); VPad.button(KeyEvent.KEYCODE_BUTTON_START, false);
            }
            return true;
        });
        return t;
    }

    // ---------------------------------------------------------------- views
    /** Image button: plays the PNG at the configured opacity, 70 % of it while pressed. */
    private final class ImgButton extends View {
        private final Bitmap bm;
        private final Runnable on, off;
        private boolean pressed;
        private final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final RectF dst = new RectF();
        ImgButton(Context c, int res, Runnable on, Runnable off) {
            super(c);
            this.on = on; this.off = off;
            bm = BitmapFactory.decodeResource(c.getResources(), res);
        }
        @Override protected void onDraw(Canvas cv) {
            if (bm == null) return;
            dst.set(0, 0, getWidth(), getHeight());
            p.setAlpha(Math.round(255 * opacity * (pressed ? 0.7f : 1f)));
            cv.drawBitmap(bm, null, dst, p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: pressed = true; invalidate(); on.run(); break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: if (pressed) { pressed = false; invalidate(); off.run(); } break;
                default: break;
            }
            return true;
        }
    }

    /** Analog stick: left/right = proportional steering, flick up/down = shift up/down. */
    private final class Stick extends View {
        private final Bitmap base, knob;
        private final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final RectF dst = new RectF();
        private float kx, ky, last;
        private boolean held, armed = true;
        private int pid = -1;
        Stick(Context c) {
            super(c);
            base = BitmapFactory.decodeResource(c.getResources(), R.drawable.joystick_base);
            knob = BitmapFactory.decodeResource(c.getResources(), R.drawable.joystick_knob);
        }
        @Override protected void onDraw(Canvas cv) {
            p.setAlpha(Math.round(255 * (held ? Math.min(1f, opacity + 0.25f) : opacity)));
            if (base != null) { dst.set(0, 0, getWidth(), getHeight()); cv.drawBitmap(base, null, dst, p); }
            if (knob != null) {
                float k = dp(80) / 2f, cx = getWidth() / 2f + kx, cy = getHeight() / 2f + ky;
                dst.set(cx - k, cy - k, cx + k, cy + k);
                cv.drawBitmap(knob, null, dst, p);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pid = e.getPointerId(0); held = true; update(e.getX(), e.getY()); break;
                case MotionEvent.ACTION_MOVE: {
                    int i = e.findPointerIndex(pid);
                    if (i >= 0) update(e.getX(i), e.getY(i));
                    break;
                }
                case MotionEvent.ACTION_POINTER_UP:
                    if (e.getPointerId(e.getActionIndex()) == pid) release();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: release(); break;
                default: break;
            }
            return true;
        }
        private void update(float x, float y) {
            float R = dp(50), dx = x - getWidth() / 2f, dy = y - getHeight() / 2f;
            float len = (float) Math.hypot(dx, dy), s = len > R ? R / len : 1f;
            kx = dx * s; ky = dy * s;
            float v = Math.max(-1f, Math.min(1f, dx / R));
            if (Math.abs(v) < 0.06f) v = 0f; else v = Math.signum(v) * (Math.abs(v) - 0.06f) / 0.94f;
            if (Math.abs(v - last) > 0.004f) { VPad.axis(AX_STEER, v); last = v; }
            float ny = dy / R;
            if (armed) {
                if (ny < -0.65f) { pulse(KeyEvent.KEYCODE_BUTTON_R1); armed = false; }      // flick up: shift up
                else if (ny > 0.65f) { pulse(KeyEvent.KEYCODE_BUTTON_L1); armed = false; }  // flick down: shift down
            } else if (Math.abs(ny) < 0.30f) armed = true;
            invalidate();
        }
        private void release() {
            held = false; kx = 0; ky = 0; last = 0; armed = true; pid = -1;
            VPad.axis(AX_STEER, 0f);
            invalidate();
        }
        private void pulse(final int key) {
            VPad.button(key, true);
            h.postDelayed(() -> VPad.button(key, false), 80);
        }
    }

    /** Round top-right icon: 0 play/pause, 1 screen ratio, 2 menu. Black 35 % disc, white 90 % glyph. */
    private final class IconButton extends View {
        private final int type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        IconButton(Context c, int type) {
            super(c);
            this.type = type;
            setClickable(true);
            setAlpha(0.85f);
        }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), hh = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(89, 0, 0, 0));
            cv.drawCircle(w / 2, hh / 2, Math.min(w, hh) / 2, p);
            p.setColor(Color.argb(230, 255, 255, 255));
            if (type == 0) {
                if (userPaused) {                                   // paused: show "play"
                    path.reset();
                    path.moveTo(w * 0.38f, hh * 0.30f); path.lineTo(w * 0.70f, hh * 0.50f); path.lineTo(w * 0.38f, hh * 0.70f);
                    path.close();
                    cv.drawPath(path, p);
                } else {                                            // running: show "pause"
                    cv.drawRoundRect(w * 0.34f, hh * 0.30f, w * 0.45f, hh * 0.70f, 3, 3, p);
                    cv.drawRoundRect(w * 0.55f, hh * 0.30f, w * 0.66f, hh * 0.70f, 3, 3, p);
                }
            } else if (type == 1) {                                 // fullscreen-style corner brackets
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(w * 0.07f);
                p.setStrokeCap(Paint.Cap.ROUND);
                float a = w * 0.30f, b = w * 0.70f, l = w * 0.14f;
                cv.drawLines(new float[] {
                        a, a + l, a, a, a, a, a + l, a,
                        b - l, a, b, a, b, a, b, a + l,
                        a, b - l, a, b, a, b, a + l, b,
                        b - l, b, b, b, b, b, b, b - l }, p);
            } else {                                                // hamburger
                float bw = w * 0.44f, bh = hh * 0.06f, gap = hh * 0.16f, x = (w - bw) / 2, y = hh / 2 - bh / 2;
                for (int i = -1; i <= 1; i++) cv.drawRoundRect(x, y + i * gap, x + bw, y + i * gap + bh, bh / 2, bh / 2, p);
            }
        }
    }

    // ---------------------------------------------------------------- pause / visibility
    private void applyPause() {
        boolean want = userPaused || panelOpen;
        if (want != lastPaused) { lastPaused = want; host.setNativePaused(want); }
    }

    private boolean realPad() {
        try {
            for (int id : InputDevice.getDeviceIds()) {
                InputDevice d = InputDevice.getDevice(id);
                if (d == null || d.isVirtual()) continue;
                int s = d.getSources();
                if ((s & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                        || (s & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private void updateVisibility() {
        boolean show = touchMode == 1 || (touchMode == 0 && !realPad());
        for (View v : gameplay) v.setVisibility(show ? VISIBLE : GONE);
        coinBtn.setVisibility(coinStart ? VISIBLE : GONE);
        startBtn.setVisibility(coinStart ? VISIBLE : GONE);
        pills.setVisibility(testService ? VISIBLE : GONE);
        invalidateAll();
    }

    private void invalidateAll() { for (int i = 0; i < getChildCount(); i++) getChildAt(i).invalidate(); }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        VPad.init();
        h.postDelayed(VPad::init, 2500);            // in case SDL was not ready yet
        h.post(keepAlive);
        InputManager im = (InputManager) getContext().getSystemService(Context.INPUT_SERVICE);
        padListener = new InputManager.InputDeviceListener() {
            @Override public void onInputDeviceAdded(int id) { updateVisibility(); }
            @Override public void onInputDeviceRemoved(int id) { updateVisibility(); }
            @Override public void onInputDeviceChanged(int id) { updateVisibility(); }
        };
        if (im != null) im.registerInputDeviceListener(padListener, h);
        updateVisibility();
    }

    @Override protected void onDetachedFromWindow() {
        h.removeCallbacks(keepAlive);
        InputManager im = (InputManager) getContext().getSystemService(Context.INPUT_SERVICE);
        if (im != null && padListener != null) im.unregisterInputDeviceListener(padListener);
        super.onDetachedFromWindow();
    }

    /** Keep the controls clear of the side navigation-bar strip and of a camera cutout. */
    @Override public WindowInsets onApplyWindowInsets(WindowInsets wi) {
        int l = 0, t = 0, r = 0, b = 0;
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Insets in = wi.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            l = in.left; r = in.right;
        } else {
            l = wi.getStableInsetLeft(); r = wi.getStableInsetRight();
        }
        if (Build.VERSION.SDK_INT >= 28) {
            DisplayCutout dc = wi.getDisplayCutout();
            if (dc != null) {
                l = Math.max(l, dc.getSafeInsetLeft()); r = Math.max(r, dc.getSafeInsetRight());
                t = dc.getSafeInsetTop(); b = dc.getSafeInsetBottom();
            }
        }
        setPadding(l, t, r, b);
        return super.onApplyWindowInsets(wi);
    }

    // ---------------------------------------------------------------- settings.txt (the game's own file): aspect ratio
    private File settingsFile() { return new File(getContext().getFilesDir(), "settings.txt"); }

    private int readAspect() {
        try (BufferedReader r = new BufferedReader(new FileReader(settingsFile()))) {
            String l;
            while ((l = r.readLine()) != null) if (l.startsWith("aspect=")) return Math.max(0, Math.min(4, Integer.parseInt(l.substring(7).trim())));
        } catch (Exception ignored) { }
        return 0;
    }

    private void writeAspect(int a) {
        List<String> out = new ArrayList<>();
        boolean done = false;
        try (BufferedReader r = new BufferedReader(new FileReader(settingsFile()))) {
            String l;
            while ((l = r.readLine()) != null) {
                if (l.startsWith("aspect=")) { out.add("aspect=" + a); done = true; }
                else if (!l.trim().isEmpty()) out.add(l);
            }
        } catch (Exception ignored) { }
        if (!done) out.add("aspect=" + a);
        try (FileWriter w = new FileWriter(settingsFile())) {
            for (String s : out) w.write(s + "\n");
        } catch (Exception ignored) { }
    }

    // ---------------------------------------------------------------- Quick options panel
    private void showPanel(int mode) {
        if (scrim == null) {
            scrim = new FrameLayout(getContext());
            scrim.setBackgroundColor(0x66000000);
            scrim.setClickable(true);
            scrim.setOnClickListener(v -> closePanel());
            card = new LinearLayout(getContext());
            card.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable g = new GradientDrawable();
            g.setColor(CARD);
            g.setCornerRadius(dp(28));
            card.setBackground(g);
            card.setPadding(dp(22), dp(16), dp(22), dp(12));
            card.setClickable(true);                       // taps on the card do not close it
            scrim.addView(card, new LayoutParams(dp(460), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        }
        if (scrim.getParent() == null) addView(scrim, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        int w = Math.min(dp(460), getWidth() - dp(32));
        if (w > 0) { LayoutParams cp = (LayoutParams) card.getLayoutParams(); cp.width = w; card.setLayoutParams(cp); }
        panelOpen = true;
        applyPause();
        renderPanel(mode);
    }

    private void closePanel() {
        if (scrim != null && scrim.getParent() != null) removeView(scrim);
        panelOpen = false;
        applyPause();
    }

    private TextView title(String s) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextColor(0xFFE6E6E6);
        t.setTextSize(22);
        t.setPadding(dp(4), 0, 0, dp(8));
        return t;
    }

    private TextView cell(String text, boolean highlight, Runnable r) {
        TextView t = new TextView(getContext());
        t.setText(text);
        t.setTextColor(ACCENT);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine();
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(dp(8), 0, dp(8), 0);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(20));
        g.setColor(highlight ? 0x334DB6F5 : Color.TRANSPARENT);
        g.setStroke(Math.max(1, dp(1.5f)), highlight ? ACCENT : LINE);
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private LinearLayout row(View a, View b) {
        LinearLayout r = new LinearLayout(getContext());
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams pa = new LinearLayout.LayoutParams(0, dp(40), 1f);
        pa.setMargins(dp(4), dp(2), dp(4), dp(2));
        LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(0, dp(40), 1f);
        pb.setMargins(dp(4), dp(2), dp(4), dp(2));
        r.addView(a, pa);
        r.addView(b == null ? new View(getContext()) : b, pb);
        return r;
    }

    private void renderPanel(int mode) {
        card.removeAllViews();
        if (mode == 1) { renderOpacity(); return; }
        if (mode == 2) { renderRatio(); return; }
        card.addView(title("Quick options"));

        TextView exit = new TextView(getContext());
        exit.setText("\u2192]   Exit game");
        exit.setTextColor(ACCENT);
        exit.setTextSize(15);
        exit.setPadding(dp(8), dp(6), 0, dp(10));
        exit.setOnClickListener(v -> { closePanel(); host.exitGame(); });
        card.addView(exit);

        card.addView(row(
                cell("Controls opacity", false, () -> renderPanel(1)),
                cell("Touch: " + TOUCH[touchMode], false, () -> {
                    touchMode = (touchMode + 1) % 3; sp.edit().putInt("touch_mode", touchMode).apply(); updateVisibility(); renderPanel(0); })));
        card.addView(row(
                cell("Coin / Start: " + (coinStart ? "Shown" : "Hidden"), false, () -> {
                    coinStart = !coinStart; sp.edit().putBoolean("coin_start", coinStart).apply(); updateVisibility(); renderPanel(0); }),
                cell("Test / Service: " + (testService ? "Shown" : "Hidden"), false, () -> {
                    testService = !testService; updateVisibility(); renderPanel(0); })));

        TextView cancel = new TextView(getContext());
        cancel.setText("Cancel");
        cancel.setTextColor(ACCENT);
        cancel.setTextSize(15);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> closePanel());
        card.addView(row(cell("Restart game", false, () -> { closePanel(); host.restartGame(); }), cancel));
    }

    private void renderOpacity() {
        card.addView(title("Controls opacity"));
        final TextView pct = new TextView(getContext());
        pct.setTextColor(0xFFE6E6E6);
        pct.setTextSize(15);
        pct.setText(Math.round(opacity * 100) + "%");
        pct.setPadding(dp(8), 0, 0, 0);
        card.addView(pct);
        SeekBar sb = new SeekBar(getContext());
        sb.setMax(80);                                   // 20 % .. 100 %
        sb.setProgress(Math.round(opacity * 100) - 20);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                opacity = (v + 20) / 100f;
                pct.setText((v + 20) + "%");
                sp.edit().putFloat("opacity", opacity).apply();
                invalidateAll();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        card.addView(sb, sp2);
        TextView done = new TextView(getContext());
        done.setText("Done");
        done.setTextColor(ACCENT);
        done.setTextSize(15);
        done.setGravity(Gravity.RIGHT);
        done.setPadding(0, dp(10), dp(8), dp(6));
        done.setOnClickListener(v -> renderPanel(0));
        card.addView(done);
    }

    private void renderRatio() {
        card.addView(title("Screen ratio"));
        int cur = readAspect();
        final String[] label = { "Auto (fill screen)", "4:3", "16:10", "16:9", "21:9" };
        card.addView(row(ratioCell(label[0], 0, cur), ratioCell(label[1], 1, cur)));
        card.addView(row(ratioCell(label[2], 2, cur), ratioCell(label[3], 3, cur)));
        TextView cancel = new TextView(getContext());
        cancel.setText("Cancel");
        cancel.setTextColor(ACCENT);
        cancel.setTextSize(15);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> closePanel());
        card.addView(row(ratioCell(label[4], 4, cur), cancel));
        TextView note = new TextView(getContext());
        note.setText("The game restarts to apply the new ratio.");
        note.setTextColor(0xFF9A9BA0);
        note.setTextSize(11);
        note.setPadding(dp(8), dp(4), 0, 0);
        card.addView(note);
    }

    private TextView ratioCell(String text, final int idx, int cur) {
        return cell((idx == cur ? "\u2713  " : "") + text, idx == cur, () -> {
            if (idx == readAspect()) { closePanel(); return; }
            writeAspect(idx);
            closePanel();
            host.restartGame();
        });
    }
}
