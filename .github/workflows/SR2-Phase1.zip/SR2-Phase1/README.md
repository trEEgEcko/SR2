# Sega Rally 2 (native recomp) - Phase 1 UI build

Java/UI-only rebuild of Rally2Recomp 0.65 beta. The game itself is the prebuilt native code in
`app/src/main/jniLibs/arm64-v8a/` (libmain.so, libSDL2.so, libc++_shared.so, taken unchanged from the 0.65 beta APK).

What changed: English launcher / ROM picker, preloader image (launcher + game start), new launcher icon
(square, round, adaptive), app name "Sega Rally 2", Super3-style round menu button (top-right) that opens the game's
settings menu, theme without the black flash.

Build: GitHub > Actions > "Build APK" > Run workflow, then download the `SegaRally2-apk` artifact.
Needs your own srally2.zip on first run, as before.
Preloader time: `PRELOADER_MS` in MainActivity.java.
