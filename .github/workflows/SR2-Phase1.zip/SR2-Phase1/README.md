# Sega Rally 2 (native recomp) - Phase 1 UI build

Java/UI-only rebuild of Rally2Recomp 0.65 beta. The game itself is the prebuilt native code in
`app/src/main/jniLibs/arm64-v8a/` (libmain.so, libSDL2.so, libc++_shared.so, taken unchanged from the 0.65 beta APK).

What changed: English launcher / ROM picker, preloader image (launcher + game start), new launcher icon
(square, round, adaptive), app name "Sega Rally 2", Super3-style round menu button (top-right) that opens the game's
settings menu, theme without the black flash.

Build: GitHub > Actions > "Build APK" > Run workflow, then download the `SegaRally2-apk` artifact.
Needs your own srally2.zip on first run, as before.
Preloader time: `PRELOADER_MS` in MainActivity.java.

## Phase 2 (this build)
- Java overlay in the Super3 style (Overlay.java): stick (steering + flick up/down to shift), gas, brake, handbrake, view,
  Coin/Start and Test/Service (hidden by default), top-right play/pause, screen-ratio and menu icons, Quick options.
- Input goes to the game as a virtual gamepad (SDL Java joystick API), so libmain.so is still untouched.
- The window now draws under a camera cutout (full-screen picture, no black bar).
- Fixed signing key (app/sr2-release.jks): new builds install over old ones. Uninstall once when switching from the debug-signed build.

## Phase 2.1
- Handbrake button removed (Sega Rally 2 has none; it capped the speed at ~60 km/h).
- Quick options trimmed: no Video settings / Screen ratio cells (ratio icon is in the top-right cluster).
- Game's own touch buttons (MENU / TEST / BACK / SERVICE / COIN / START) stay hidden: the overlay keeps the game's
  "gamepad in use" flag alive and swallows stray touches. COIN / START of the overlay are shown by default (the game needs a coin).
- Controls stay clear of the side navigation-bar strip; default opacity 55 %.

## Phase 2.2
- Menus work by touch again (tap a car, second tap confirms, drag the name ring, tap to enter a letter): touches that miss a
  control now reach the game. The two bonus cars can only be picked by tapping them (the game's cabinet cursor skips them).
- Overlay keeps the game's "gamepad in use" flag alive with a zero-brake rest value, so the game's own buttons stay hidden.
- Quick options: "Menu back" taps the game's invisible BACK button (one page back in the menus).
- New preloader image (5 cars), centred in the visible area (clear of the navigation-bar strip).
